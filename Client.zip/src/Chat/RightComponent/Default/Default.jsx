import React from 'react';

const Default = () => {
    return (
        <div className="d-flex justify-content-center align-items-center flex-column" style={{ width: "100%", height: "100%",overflow:"hidden" }}>
            <div className="text-center" >
            </div>
            <div className="text-center" >
                <h3>Avvocato Chat Messanger</h3>
                <p className="h6">Start Your Chat Now</p>
            </div>
        </div>
    )
}

export default Default;